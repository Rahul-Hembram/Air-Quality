Trained .joblib model files will be saved here after running main.py.
