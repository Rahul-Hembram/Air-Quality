# Bhagalpur Air Quality Prediction

A modular Python project for next-day PM2.5 regression using:
- Linear Regression
- Random Forest Regressor
- XGBoost Regressor
- Persistence baseline (today's PM2.5 used as tomorrow's estimate)

## 1. Project folder layout

```text
Bhagalpur_Air_Quality_Project/
├── data/
│   └── bhagalpur_daily_data.csv
├── models/
├── outputs/
│   ├── graphs/
│   └── reports/
├── src/
│   ├── __init__.py
│   ├── config.py
│   ├── data_utils.py
│   ├── models.py
│   ├── pipeline.py
│   ├── reporting.py
│   └── validation.py
├── main.py
└── requirements.txt
```

## 2. Add your dataset

Copy your existing CSV into `data/` and name it:

`bhagalpur_daily_data.csv`

The CSV must contain these columns (case-insensitive):
`date`, `co`, `no`, `no2`, `nox`, `o3`, `pm10`, `pm25`,
`relativehumidity`, `so2`, `temperature`, `wind_direction`,
`wind_speed`, `next_day_pm25`.

If your CSV has a different filename, edit `DATA_FILE` in `src/config.py`.

## 3. Run in VS Code on Windows

Open this folder in VS Code. Open **Terminal → New Terminal**, then run:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

If PowerShell blocks activation, run this once in the same terminal:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Then activate `.venv` again.

## 4. Generated outputs

After a successful run:
- `models/linear_regression.joblib`
- `models/random_forest.joblib`
- `models/xgboost.joblib`
- `models/best_model.joblib`
- `outputs/reports/model_metrics.csv`
- `outputs/reports/baseline_metrics.csv`
- `outputs/reports/project_report.pdf`
- `outputs/graphs/model_comparison.png`
- `outputs/graphs/actual_vs_predicted_best_model.png`
- Feature-importance charts for Random Forest and XGBoost
- Per-model prediction CSV files in `outputs/graphs/`

## 5. Methodology and cautions

- The data is sorted by date and split chronologically (first 80% train, final 20% test).
- Missing input values are imputed with the median learned from training data inside each model pipeline.
- Rows without `next_day_pm25` are not used for supervised training.
- Target alignment is checked against the following row's `pm25` value. The check is a diagnostic; inspect the output if mismatches or missing comparisons occur.
- The persistence baseline uses same-day `pm25` as the next-day estimate. Missing test-day `pm25` values use the training-set median.
- The dataset previously discussed has only 55 labelled rows and 11 test rows. Metrics from such a small test set are unstable. Negative R² means a model performed worse than predicting the test-set mean.
- Feature importance is a model-specific measure, not proof of causation.
- This is an academic experiment, not an official AQI calculation or a validated public-health forecasting service.
