import pandas as pd
from src.config import DATE_COLUMN, TARGET_COLUMN, FEATURE_COLUMNS

def load_and_prepare_data(csv_path):
    df = pd.read_csv(csv_path)
    df.columns = [str(c).strip().lower() for c in df.columns]

    required = [DATE_COLUMN, TARGET_COLUMN] + FEATURE_COLUMNS
    missing_columns = [c for c in required if c not in df.columns]
    if missing_columns:
        raise ValueError(
            "CSV is missing required columns: " + ", ".join(missing_columns)
        )

    df[DATE_COLUMN] = pd.to_datetime(df[DATE_COLUMN], errors="coerce")
    for col in FEATURE_COLUMNS + [TARGET_COLUMN]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df = df.dropna(subset=[DATE_COLUMN]).sort_values(DATE_COLUMN)
    df = df.drop_duplicates(subset=[DATE_COLUMN], keep="last").reset_index(drop=True)

    # Supervised training requires a known target. Input-feature missing values
    # are imputed inside each model pipeline using training data only.
    labelled = df.dropna(subset=[TARGET_COLUMN]).copy().reset_index(drop=True)

    if len(labelled) < 10:
        raise ValueError(
            f"Only {len(labelled)} rows have a target. At least 10 are needed "
            "for this demonstration; more data is strongly recommended."
        )

    return df, labelled
