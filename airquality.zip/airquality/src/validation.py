import numpy as np
import pandas as pd
from src.config import DATE_COLUMN, TARGET_COLUMN

def check_next_day_alignment(df):
    check = df.copy()
    check["following_date"] = check[DATE_COLUMN].shift(-1)
    check["following_pm25"] = check["pm25"].shift(-1)
    check["date_gap_days"] = (
        check["following_date"] - check[DATE_COLUMN]
    ).dt.days

    valid = check.dropna(subset=[TARGET_COLUMN, "following_pm25"])
    if valid.empty:
        return {
            "comparisons": 0,
            "matches": 0,
            "non_consecutive_date_gaps": 0,
            "note": "No rows available for alignment comparison."
        }

    matches = np.isclose(
        valid[TARGET_COLUMN].to_numpy(),
        valid["following_pm25"].to_numpy(),
        atol=1e-6
    )
    return {
        "comparisons": int(len(valid)),
        "matches": int(matches.sum()),
        "non_consecutive_date_gaps": int((valid["date_gap_days"] != 1).sum()),
        "note": "Alignment check compares next_day_pm25 with the next row's pm25."
    }
