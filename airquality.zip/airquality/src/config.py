from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
MODEL_DIR = PROJECT_ROOT / "models"
OUTPUT_DIR = PROJECT_ROOT / "outputs"
GRAPH_DIR = OUTPUT_DIR / "graphs"
REPORT_DIR = OUTPUT_DIR / "reports"

# Put your CSV in data/ and update this name if needed.
DATA_FILE = DATA_DIR / "bhagalpur_daily_data.csv"

DATE_COLUMN = "date"
TARGET_COLUMN = "next_day_pm25"

FEATURE_COLUMNS = [
    "co", "no", "no2", "nox", "o3", "pm10", "pm25",
    "relativehumidity", "so2", "temperature",
    "wind_direction", "wind_speed"
]

TEST_SIZE = 0.20
RANDOM_STATE = 42
