import json
import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from src.config import (
    DATA_FILE, MODEL_DIR, GRAPH_DIR, REPORT_DIR,
    FEATURE_COLUMNS, TARGET_COLUMN, DATE_COLUMN, TEST_SIZE, RANDOM_STATE
)
from src.data_utils import load_and_prepare_data
from src.models import build_models
from src.validation import check_next_day_alignment
from src.reporting import (
    save_comparison_plot, save_actual_predicted_plot,
    save_feature_importance, create_pdf_report
)

def metrics(y_true, y_pred):
    return {
        "MAE": float(mean_absolute_error(y_true, y_pred)),
        "MSE": float(mean_squared_error(y_true, y_pred)),
        "RMSE": float(np.sqrt(mean_squared_error(y_true, y_pred))),
        "R2": float(r2_score(y_true, y_pred))
    }

def run_project():
    for folder in [MODEL_DIR, GRAPH_DIR, REPORT_DIR]:
        folder.mkdir(parents=True, exist_ok=True)

    if not DATA_FILE.exists():
        raise FileNotFoundError(
            f"Dataset not found: {DATA_FILE}\n"
            "Copy your CSV into the data folder and name it "
            "'bhagalpur_daily_data.csv', or update DATA_FILE in src/config.py."
        )

    full_df, df = load_and_prepare_data(DATA_FILE)
    alignment = check_next_day_alignment(full_df)

    split_index = int(len(df) * (1 - TEST_SIZE))
    if split_index < 2 or len(df) - split_index < 2:
        raise ValueError("Not enough labelled rows for chronological train/test split.")

    train_df = df.iloc[:split_index].copy()
    test_df = df.iloc[split_index:].copy()

    X_train = train_df[FEATURE_COLUMNS]
    X_test = test_df[FEATURE_COLUMNS]
    y_train = train_df[TARGET_COLUMN]
    y_test = test_df[TARGET_COLUMN]

    print("\n=== DATASET ===")
    print(f"All dated rows: {len(full_df)}")
    print(f"Rows with target: {len(df)}")
    print(f"Features: {len(FEATURE_COLUMNS)}")
    print(f"Training rows: {len(train_df)}")
    print(f"Testing rows: {len(test_df)}")
    print(f"Training period: {train_df[DATE_COLUMN].min().date()} to {train_df[DATE_COLUMN].max().date()}")
    print(f"Testing period: {test_df[DATE_COLUMN].min().date()} to {test_df[DATE_COLUMN].max().date()}")
    print("\n=== TARGET ALIGNMENT ===")
    print(json.dumps(alignment, indent=2))

    models = build_models(RANDOM_STATE)
    rows = []
    predictions = {}

    for name, model in models.items():
        print(f"\nTraining {name}...")
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        predictions[name] = pred
        score = metrics(y_test, pred)
        rows.append({"Model": name, **score})
        safe_name = name.lower().replace(" ", "_")
        joblib.dump(model, MODEL_DIR / f"{safe_name}.joblib")
        pd.DataFrame({
            "date": test_df[DATE_COLUMN].values,
            "actual_next_day_pm25": y_test.values,
            "predicted_next_day_pm25": pred,
            "error_actual_minus_predicted": y_test.values - pred
        }).to_csv(GRAPH_DIR / f"{safe_name}_predictions.csv", index=False)

    results = pd.DataFrame(rows)
    results.to_csv(REPORT_DIR / "model_metrics.csv", index=False)

    # Fair persistence baseline: today's pm25 is used as tomorrow's prediction.
    # Missing current-day PM2.5 values are filled using the training median only.
    pm25_median = X_train["pm25"].median()
    baseline_pred = X_test["pm25"].fillna(pm25_median).to_numpy()
    baseline = metrics(y_test, baseline_pred)
    pd.DataFrame([baseline]).to_csv(REPORT_DIR / "baseline_metrics.csv", index=False)

    best_row = results.sort_values("MAE").iloc[0]
    best_name = best_row["Model"]
    best_pred = predictions[best_name]

    save_comparison_plot(
        pd.concat([
            results[["Model", "MAE", "RMSE"]],
            pd.DataFrame([{"Model": "Persistence Baseline",
                           "MAE": baseline["MAE"], "RMSE": baseline["RMSE"]}])
        ], ignore_index=True),
        GRAPH_DIR / "model_comparison.png"
    )
    save_actual_predicted_plot(
        test_df[DATE_COLUMN], y_test, best_pred,
        GRAPH_DIR / "actual_vs_predicted_best_model.png", best_name
    )

    for name in ["Random Forest", "XGBoost"]:
        safe_name = name.lower().replace(" ", "_")
        save_feature_importance(
            models[name], FEATURE_COLUMNS,
            GRAPH_DIR / f"{safe_name}_feature_importance.png",
            f"{name} feature importance"
        )

    best_model_path = MODEL_DIR / (best_name.lower().replace(" ", "_") + ".joblib")
    joblib.dump(joblib.load(best_model_path), MODEL_DIR / "best_model.joblib")

    report_path = REPORT_DIR / "project_report.pdf"
    graph_paths = [
        GRAPH_DIR / "model_comparison.png",
        GRAPH_DIR / "actual_vs_predicted_best_model.png",
        GRAPH_DIR / "random_forest_feature_importance.png",
        GRAPH_DIR / "xgboost_feature_importance.png"
    ]
    create_pdf_report(
        results, best_name, baseline, alignment,
        len(train_df), len(test_df),
        str(df[DATE_COLUMN].min().date()), str(df[DATE_COLUMN].max().date()),
        graph_paths, report_path
    )

    print("\n=== MODEL RESULTS ===")
    print(results.round(4).to_string(index=False))
    print("\nPersistence Baseline:", {k: round(v, 4) for k, v in baseline.items()})
    print(f"\nBest ML model by MAE: {best_name}")
    print(f"Saved models to: {MODEL_DIR}")
    print(f"Saved graphs to: {GRAPH_DIR}")
    print(f"Saved PDF report to: {report_path}")
    print("\nNote: the best ML model is selected by MAE among ML models only; "
          "the persistence baseline is reported separately.")
