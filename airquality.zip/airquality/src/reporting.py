from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from src.config import GRAPH_DIR, REPORT_DIR, DATE_COLUMN

def save_comparison_plot(results, path):
    fig, ax = plt.subplots(figsize=(9, 5))
    names = results["Model"].tolist()
    x = np.arange(len(names))
    width = 0.35
    ax.bar(x - width/2, results["MAE"], width, label="MAE")
    ax.bar(x + width/2, results["RMSE"], width, label="RMSE")
    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=12, ha="right")
    ax.set_ylabel("Error (PM2.5 units)")
    ax.set_title("Model comparison: MAE and RMSE")
    ax.legend()
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)

def save_actual_predicted_plot(dates, actual, predicted, path, model_name):
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(dates, actual, marker="o", label="Actual")
    ax.plot(dates, predicted, marker="s", label="Predicted")
    ax.set_title(f"{model_name}: actual vs predicted next-day PM2.5")
    ax.set_xlabel("Date")
    ax.set_ylabel("Next-day PM2.5")
    ax.tick_params(axis="x", rotation=40)
    ax.legend()
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)

def save_feature_importance(model, feature_names, path, title):
    estimator = model.named_steps["model"]
    if not hasattr(estimator, "feature_importances_"):
        return False
    values = estimator.feature_importances_
    order = np.argsort(values)
    fig, ax = plt.subplots(figsize=(9, 6))
    ax.barh(np.array(feature_names)[order], values[order])
    ax.set_title(title)
    ax.set_xlabel("Feature importance")
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)
    return True

def create_pdf_report(results, best_ml_name, baseline_metrics, alignment,
                      train_rows, test_rows, date_start, date_end,
                      graph_paths, report_path):
    styles = getSampleStyleSheet()
    doc = SimpleDocTemplate(str(report_path), pagesize=A4)
    story = [
        Paragraph("Bhagalpur Air Quality: Next-Day PM2.5 Prediction", styles["Title"]),
        Spacer(1, 12),
        Paragraph(
            "This report evaluates regression models for predicting next-day "
            "PM2.5 using the supplied daily pollution and weather features.",
            styles["BodyText"]
        ),
        Spacer(1, 10),
        Paragraph(f"Dataset period: {date_start} to {date_end}", styles["BodyText"]),
        Paragraph(f"Training rows: {train_rows}; testing rows: {test_rows}", styles["BodyText"]),
        Paragraph(f"Best machine-learning model by test MAE: {best_ml_name}", styles["BodyText"]),
        Spacer(1, 12),
        Paragraph("Test-set model metrics", styles["Heading2"])
    ]

    table_data = [["Model", "MAE", "RMSE", "R2"]]
    for _, row in results.iterrows():
        table_data.append([
            str(row["Model"]), f'{row["MAE"]:.4f}',
            f'{row["RMSE"]:.4f}', f'{row["R2"]:.4f}'
        ])
    table_data.append([
        "Persistence Baseline",
        f'{baseline_metrics["MAE"]:.4f}',
        f'{baseline_metrics["RMSE"]:.4f}',
        f'{baseline_metrics["R2"]:.4f}'
    ])
    table = Table(table_data, repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dce6f1")),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("PADDING", (0, 0), (-1, -1), 6),
    ]))
    story += [table, Spacer(1, 12), Paragraph("Target alignment check", styles["Heading2"])]
    story.append(Paragraph(
        f'Comparisons: {alignment["comparisons"]}; matching values: '
        f'{alignment["matches"]}; non-consecutive date gaps: '
        f'{alignment["non_consecutive_date_gaps"]}.',
        styles["BodyText"]
    ))
    story.append(Spacer(1, 8))
    story.append(Paragraph(
        "Interpretation: Lower MAE and RMSE are better. R2 can be negative when "
        "the model performs worse than predicting the test-set mean. The "
        "persistence baseline uses the current day's PM2.5 as the next-day "
        "prediction. Results are experimental because the dataset is small; "
        "they should not be treated as an operational air-quality forecast.",
        styles["BodyText"]
    ))
    for graph in graph_paths:
        if Path(graph).exists():
            story += [Spacer(1, 12), Paragraph(Path(graph).stem.replace("_", " ").title(), styles["Heading2"])]
            from reportlab.platypus import Image
            story.append(Image(str(graph), width=460, height=250))
    doc.build(story)
