
from pathlib import Path

import joblib
import pandas as pd
import streamlit as st

from src.config import (
    PROJECT_ROOT,
    DATA_FILE,
    MODEL_DIR,
    GRAPH_DIR,
    REPORT_DIR,
    FEATURE_COLUMNS,
    TARGET_COLUMN,
    DATE_COLUMN,
)

# --------------------------------------------------
# PAGE CONFIGURATION
# --------------------------------------------------

st.set_page_config(
    page_title="Bhagalpur Air Quality Prediction",
    page_icon="🌍",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --------------------------------------------------
# CUSTOM CSS
# --------------------------------------------------

st.markdown("""
<style>
    .stApp {
        background-color: #f5f7fb;
    }

    [data-testid="stSidebar"] {
        background-color: #14213d;
    }

    [data-testid="stSidebar"] * {
        color: white !important;
    }

    .main-title {
        font-size: 34px;
        font-weight: 800;
        color: #14213d;
        margin-bottom: 5px;
    }

    .subtitle {
        color: #64748b;
        font-size: 15px;
        margin-bottom: 25px;
    }

    .section-title {
        font-size: 23px;
        font-weight: 700;
        color: #14213d;
        margin-top: 20px;
    }

    .info-card {
        background-color: white;
        padding: 20px;
        border-radius: 12px;
        border: 1px solid #e2e8f0;
        margin-bottom: 10px;
    }

    .small-note {
        color: #64748b;
        font-size: 13px;
    }

    div[data-testid="stMetric"] {
        background-color: white;
        border: 1px solid #e2e8f0;
        padding: 16px;
        border-radius: 12px;
    }

    .stButton > button {
        background-color: #2563eb;
        color: white;
        border-radius: 8px;
        border: none;
        padding: 9px 20px;
        font-weight: 600;
    }

    .stButton > button:hover {
        background-color: #1d4ed8;
        color: white;
    }
</style>
""", unsafe_allow_html=True)


# --------------------------------------------------
# DATA LOADING
# --------------------------------------------------

@st.cache_data
def load_dataset():
    if not DATA_FILE.exists():
        raise FileNotFoundError(
            f"Dataset not found at: {DATA_FILE}"
        )

    df = pd.read_csv(DATA_FILE)

    if DATE_COLUMN not in df.columns:
        raise ValueError(f"Missing date column: {DATE_COLUMN}")

    df[DATE_COLUMN] = pd.to_datetime(
        df[DATE_COLUMN], errors="coerce"
    )

    df = df.dropna(subset=[DATE_COLUMN])
    df = df.sort_values(DATE_COLUMN).reset_index(drop=True)

    missing_features = [
        col for col in FEATURE_COLUMNS
        if col not in df.columns
    ]

    if missing_features:
        raise ValueError(
            f"Missing required features: {missing_features}"
        )

    return df


# --------------------------------------------------
# MODEL LOADING
# --------------------------------------------------

@st.cache_resource
def load_models():
    model_files = {
        "Linear Regression": MODEL_DIR / "linear_regression.joblib",
        "Random Forest": MODEL_DIR / "random_forest.joblib",
        "XGBoost": MODEL_DIR / "xgboost.joblib",
        "Best Model": MODEL_DIR / "best_model.joblib",
    }

    loaded_models = {}

    for name, path in model_files.items():
        if path.exists():
            loaded_models[name] = joblib.load(path)

    return loaded_models


# --------------------------------------------------
# METRICS LOADING
# --------------------------------------------------

@st.cache_data
def load_metrics():
    metrics_file = REPORT_DIR / "model_metrics.csv"
    baseline_file = REPORT_DIR / "baseline_metrics.csv"

    metrics_df = (
        pd.read_csv(metrics_file)
        if metrics_file.exists()
        else pd.DataFrame()
    )

    baseline_df = (
        pd.read_csv(baseline_file)
        if baseline_file.exists()
        else pd.DataFrame()
    )

    return metrics_df, baseline_df


# --------------------------------------------------
# HELPER FUNCTIONS
# --------------------------------------------------

def pollution_category(value):
    if pd.isna(value):
        return "Unavailable"

    if value <= 30:
        return "Good"
    elif value <= 60:
        return "Satisfactory"
    elif value <= 90:
        return "Moderate"
    elif value <= 120:
        return "Poor"
    elif value <= 250:
        return "Very Poor"
    else:
        return "Severe"


def get_model_slug(model_name):
    return model_name.lower().replace(" ", "_")


def show_page_heading(title, description):
    st.markdown(
        f'<div class="main-title">{title}</div>',
        unsafe_allow_html=True
    )
    st.markdown(
        f'<div class="subtitle">{description}</div>',
        unsafe_allow_html=True
    )


# --------------------------------------------------
# INITIALIZE PROJECT
# --------------------------------------------------

try:
    df = load_dataset()
    models = load_models()
    metrics_df, baseline_df = load_metrics()

except Exception as error:
    st.error(f"Project initialization failed: {error}")
    st.info(
        "Check that your dataset is inside the data folder "
        "and run python main.py to generate the models."
    )
    st.stop()


if not models:
    st.error("No trained models found in the models folder.")
    st.info("Run this command in the project terminal: python main.py")
    st.stop()


# --------------------------------------------------
# SIDEBAR NAVIGATION
# --------------------------------------------------

st.sidebar.markdown("# 🌍 Air Quality")
st.sidebar.markdown("### Bhagalpur, Bihar")
st.sidebar.markdown("---")

page = st.sidebar.radio(
    "NAVIGATION",
    [
        "Dashboard",
        "PM2.5 Prediction",
        "Historical Analysis",
        "Model Performance",
        "Feature Importance",
        "Reports",
        "About Project",
    ]
)

st.sidebar.markdown("---")
st.sidebar.caption("Machine Learning Project")
st.sidebar.caption("Air Quality Prediction System")


# --------------------------------------------------
# DASHBOARD
# --------------------------------------------------

if page == "Dashboard":

    show_page_heading(
        "Bhagalpur Air Quality Dashboard",
        "Monitor historical pollution measurements and explore next-day PM2.5 predictions."
    )

    latest = df.iloc[-1]

    pm25_value = latest["pm25"] if "pm25" in df.columns else None

    if pm25_value is not None and pd.notna(pm25_value):
        category = pollution_category(pm25_value)
    else:
        category = "Unavailable"

    col1, col2, col3, col4 = st.columns(4)

    col1.metric(
        "Latest PM2.5",
        f"{pm25_value:.2f}" if pd.notna(pm25_value) else "N/A",
        "µg/m³"
    )

    col2.metric(
        "Pollution Category",
        category
    )

    col3.metric(
        "Dataset Records",
        len(df)
    )

    col4.metric(
        "Available ML Models",
        len(models)
    )

    st.markdown("## Air Quality Overview")

    left, right = st.columns(2)

    with left:
        st.markdown("### Historical PM2.5")

        if "pm25" in df.columns:
            chart_df = df.set_index(DATE_COLUMN)[["pm25"]]
            st.line_chart(chart_df)
        else:
            st.warning("PM2.5 column is unavailable.")

    with right:
        st.markdown("### Other Pollutants")

        pollutant_columns = [
            col for col in ["pm10", "no2", "so2", "co", "o3"]
            if col in df.columns
        ]

        if pollutant_columns:
            st.line_chart(
                df.set_index(DATE_COLUMN)[pollutant_columns]
            )

    st.markdown("## Latest Available Record")

    st.write(
        f"**Date:** {latest[DATE_COLUMN].strftime('%d %B %Y')}"
    )

    st.dataframe(
        pd.DataFrame([latest]),
        use_container_width=True,
        hide_index=True
    )

    st.info(
        "This dashboard uses the available historical dataset. "
        "It does not display live sensor readings."
    )


# --------------------------------------------------
# PM2.5 PREDICTION
# --------------------------------------------------

elif page == "PM2.5 Prediction":

    show_page_heading(
        "Next-Day PM2.5 Prediction",
        "Select a date and machine learning model to estimate the next day's PM2.5 concentration."
    )

    prediction_df = df.copy()

    available_dates = prediction_df[DATE_COLUMN].dt.strftime(
        "%Y-%m-%d"
    ).tolist()

    selected_date = st.selectbox(
        "Select observation date",
        available_dates,
        index=len(available_dates) - 1
    )

    selected_row = prediction_df[
        prediction_df[DATE_COLUMN].dt.strftime("%Y-%m-%d")
        == selected_date
    ].iloc[0]

    available_model_names = list(models.keys())

    selected_model_name = st.selectbox(
        "Select prediction model",
        available_model_names
    )

    st.markdown("### Input Parameters")

    input_df = pd.DataFrame(
        [selected_row[FEATURE_COLUMNS].to_dict()]
    )

    with st.expander("View the 12 model input features"):
        st.dataframe(
            input_df,
            use_container_width=True,
            hide_index=True
        )

    if st.button("Predict Next-Day PM2.5", use_container_width=True):

        try:
            selected_model = models[selected_model_name]

            prediction = selected_model.predict(input_df)[0]

            st.markdown("---")
            st.markdown("## Prediction Result")

            col1, col2 = st.columns(2)

            col1.metric(
                "Predicted Next-Day PM2.5",
                f"{prediction:.2f} µg/m³"
            )

            col2.metric(
                "Estimated Category",
                pollution_category(prediction)
            )

            st.success(
                f"Estimated PM2.5 for the day after "
                f"{selected_date}: {prediction:.2f} µg/m³"
            )

            st.caption(
                "This is a model estimate, not a real-time measurement "
                "or a guaranteed forecast."
            )

        except Exception as error:
            st.error(f"Prediction failed: {error}")


# --------------------------------------------------
# HISTORICAL ANALYSIS
# --------------------------------------------------

elif page == "Historical Analysis":

    show_page_heading(
        "Historical Air Quality Analysis",
        "Explore pollution trends and changes in environmental measurements."
    )

    if "pm25" in df.columns:

        st.markdown("### PM2.5 Trend")

        st.line_chart(
            df.set_index(DATE_COLUMN)[["pm25"]]
        )

        st.markdown("### PM2.5 Statistics")

        stats = df["pm25"].describe().to_frame().T
        st.dataframe(stats, use_container_width=True)

    pollutant_columns = [
        col for col in [
            "pm25", "pm10", "no2", "nox", "so2", "co", "o3"
        ]
        if col in df.columns
    ]

    if pollutant_columns:
        st.markdown("### Compare Pollutants")

        selected_pollutants = st.multiselect(
            "Choose pollutants",
            pollutant_columns,
            default=["pm25", "pm10"] if "pm10" in pollutant_columns else ["pm25"]
        )

        if selected_pollutants:
            st.line_chart(
                df.set_index(DATE_COLUMN)[selected_pollutants]
            )

    st.markdown("### Complete Historical Dataset")

    st.dataframe(
        df,
        use_container_width=True,
        hide_index=True
    )

    st.download_button(
        "Download Historical Dataset",
        data=df.to_csv(index=False).encode("utf-8"),
        file_name="bhagalpur_air_quality_data.csv",
        mime="text/csv"
    )


# --------------------------------------------------
# MODEL PERFORMANCE
# --------------------------------------------------

elif page == "Model Performance":

    show_page_heading(
        "Model Performance Evaluation",
        "Compare machine learning models using regression evaluation metrics."
    )

    if metrics_df.empty:
        st.warning("Model metrics are not available. Run python main.py.")
    else:

        st.markdown("### Machine Learning Model Comparison")

        st.dataframe(
            metrics_df.round(4),
            use_container_width=True,
            hide_index=True
        )

        if "MAE" in metrics_df.columns:
            st.markdown("### Mean Absolute Error (MAE)")
            st.bar_chart(
                metrics_df.set_index("Model")[["MAE"]]
            )

        if "RMSE" in metrics_df.columns:
            st.markdown("### Root Mean Squared Error (RMSE)")
            st.bar_chart(
                metrics_df.set_index("Model")[["RMSE"]]
            )

        if "R2" in metrics_df.columns:
            st.markdown("### R² Score")
            st.bar_chart(
                metrics_df.set_index("Model")[["R2"]]
            )

    if not baseline_df.empty:

        st.markdown("### Persistence Baseline")

        st.write(
            "The persistence baseline assumes that tomorrow's PM2.5 "
            "will be equal to today's PM2.5."
        )

        st.dataframe(
            baseline_df.round(4),
            use_container_width=True,
            hide_index=True
        )

    st.info(
        "Lower MAE and RMSE generally indicate better predictions. "
        "A higher R² is generally preferable. The persistence baseline "
        "is reported separately from the trained ML models."
    )

    comparison_graph = GRAPH_DIR / "model_comparison.png"

    if comparison_graph.exists():
        st.markdown("### Saved Model Comparison Graph")
        st.image(str(comparison_graph), use_container_width=True)


# --------------------------------------------------
# FEATURE IMPORTANCE
# --------------------------------------------------

elif page == "Feature Importance":

    show_page_heading(
        "Feature Importance Analysis",
        "Explore which environmental variables contributed most to the tree-based models."
    )

    importance_files = {
        "Random Forest": GRAPH_DIR / "random_forest_feature_importance.png",
        "XGBoost": GRAPH_DIR / "xgboost_feature_importance.png",
    }

    for model_name, graph_path in importance_files.items():

        st.markdown(f"### {model_name}")

        if graph_path.exists():
            st.image(str(graph_path), use_container_width=True)
        else:
            st.warning(
                f"Feature importance graph not found: {graph_path.name}"
            )

    st.caption(
        "Feature importance indicates model-specific contribution scores. "
        "It does not establish that a feature causes a change in pollution."
    )


# --------------------------------------------------
# REPORTS
# --------------------------------------------------

elif page == "Reports":

    show_page_heading(
        "Project Reports and Downloads",
        "Access generated model reports, graphs, and prediction results."
    )

    report_file = REPORT_DIR / "project_report.pdf"

    if report_file.exists():

        with open(report_file, "rb") as file:
            st.download_button(
                "Download Project Report (PDF)",
                data=file,
                file_name="Bhagalpur_Air_Quality_Project_Report.pdf",
                mime="application/pdf",
                use_container_width=True
            )

    else:
        st.warning("Project PDF report not found.")

    metrics_file = REPORT_DIR / "model_metrics.csv"

    if metrics_file.exists():

        with open(metrics_file, "rb") as file:
            st.download_button(
                "Download Model Metrics (CSV)",
                data=file,
                file_name="model_metrics.csv",
                mime="text/csv"
            )

    prediction_files = list(GRAPH_DIR.glob("*_predictions.csv"))

    st.markdown("### Model Prediction Files")

    if prediction_files:

        for prediction_file in prediction_files:

            with open(prediction_file, "rb") as file:
                st.download_button(
                    f"Download {prediction_file.name}",
                    data=file,
                    file_name=prediction_file.name,
                    mime="text/csv",
                    key=prediction_file.name
                )

    else:
        st.info("No saved prediction files were found.")

    st.markdown("### Generated Graphs")

    graph_files = [
        path for path in GRAPH_DIR.glob("*.png")
    ]

    if graph_files:
        for graph in graph_files:
            with st.expander(graph.name):
                st.image(str(graph), use_container_width=True)
    else:
        st.info("No graphs found.")


# --------------------------------------------------
# ABOUT PROJECT
# --------------------------------------------------

elif page == "About Project":

    show_page_heading(
        "About the Project",
        "Machine learning-based next-day PM2.5 prediction for Bhagalpur, Bihar."
    )

    st.markdown("""
    ## Project Overview

    This project analyzes historical air quality and weather measurements
    to estimate next-day PM2.5 concentration.

    ## Objectives

    - Analyze historical air pollution measurements.
    - Study relationships between pollutants and weather variables.
    - Train and compare regression models.
    - Predict next-day PM2.5 concentration.
    - Visualize model performance and feature importance.

    ## Machine Learning Algorithms

    1. Linear Regression
    2. Random Forest Regression
    3. XGBoost Regression

    ## Input Features

    The model uses 12 input features:

    - CO
    - NO
    - NO2
    - NOx
    - O3
    - PM10
    - PM2.5
    - Relative Humidity
    - SO2
    - Temperature
    - Wind Direction
    - Wind Speed

    ## Target Variable

    `next_day_pm25`

    ## Technology Stack

    - Python
    - Pandas and NumPy
    - Scikit-learn
    - XGBoost
    - Matplotlib
    - Streamlit
    - Joblib

    ## System Workflow

    Historical Dataset → Data Preparation → Feature Selection →
    Chronological Train-Test Split → Model Training →
    Model Evaluation → Prediction → Dashboard

    ## Important Note

    The pollution categories displayed in this application use
    project-defined PM2.5 concentration bands. They are not official
    AQI categories. The project uses historical data and does not
    provide live monitoring.
    """)

    st.markdown("---")
    st.caption("Bhagalpur Air Quality Prediction | Machine Learning Project")
