Generated graphs, CSV metrics, and PDF report will be saved in this folder.
